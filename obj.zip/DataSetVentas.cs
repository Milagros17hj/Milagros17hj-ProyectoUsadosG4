﻿namespace ProyectoUsadosGrupo4
{


    partial class DataSetVentas
    {
    }
}
