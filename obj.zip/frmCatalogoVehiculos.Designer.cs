﻿namespace ProyectoUsadosGrupo4
{
    partial class frmCatalogoVehiculos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCatalogoVehiculos));
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblPrecioJac1 = new System.Windows.Forms.Label();
            this.lblPrecioGeely = new System.Windows.Forms.Label();
            this.lblPrecioZeekrX = new System.Windows.Forms.Label();
            this.lblPrecioJac4 = new System.Windows.Forms.Label();
            this.btnJac1 = new System.Windows.Forms.Button();
            this.btnGeely = new System.Windows.Forms.Button();
            this.lblJac1 = new System.Windows.Forms.Label();
            this.lblGeely = new System.Windows.Forms.Label();
            this.btnZeerkX = new System.Windows.Forms.Button();
            this.lblZeekrX = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnJac4 = new System.Windows.Forms.Button();
            this.lblJac4 = new System.Windows.Forms.Label();
            this.pbJac1 = new System.Windows.Forms.PictureBox();
            this.pbZeekrX = new System.Windows.Forms.PictureBox();
            this.pbGeely = new System.Windows.Forms.PictureBox();
            this.pbJac4 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblPrecioHilux = new System.Windows.Forms.Label();
            this.lblPrecioNissan = new System.Windows.Forms.Label();
            this.lblChevrolet = new System.Windows.Forms.Label();
            this.lblPrecioJacT8 = new System.Windows.Forms.Label();
            this.lblHilux = new System.Windows.Forms.Label();
            this.lblNissan = new System.Windows.Forms.Label();
            this.lblPrecioChevrolet = new System.Windows.Forms.Label();
            this.btnHilux = new System.Windows.Forms.Button();
            this.btnNissan = new System.Windows.Forms.Button();
            this.btnChevrolet = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnJacT8 = new System.Windows.Forms.Button();
            this.lblJact8 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pbChevrolet = new System.Windows.Forms.PictureBox();
            this.pb = new System.Windows.Forms.PictureBox();
            this.pbJacT8 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblPrecioAccent = new System.Windows.Forms.Label();
            this.lblPrecioSuzuki = new System.Windows.Forms.Label();
            this.lblPrecioYaris = new System.Windows.Forms.Label();
            this.lblAudi = new System.Windows.Forms.Label();
            this.lblAccent = new System.Windows.Forms.Label();
            this.lblSuzuki = new System.Windows.Forms.Label();
            this.btnAccent = new System.Windows.Forms.Button();
            this.btnSuzuki = new System.Windows.Forms.Button();
            this.pbSuzuki = new System.Windows.Forms.PictureBox();
            this.btnYaris = new System.Windows.Forms.Button();
            this.lblYaris = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pbAccent = new System.Windows.Forms.PictureBox();
            this.btnAudi = new System.Windows.Forms.Button();
            this.lblAudio = new System.Windows.Forms.Label();
            this.pbYaris = new System.Windows.Forms.PictureBox();
            this.pbAudi = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnSalir = new System.Windows.Forms.Button();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbJac1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbZeekrX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGeely)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbJac4)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbChevrolet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbJacT8)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSuzuki)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAccent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbYaris)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAudi)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.panel1);
            this.flowLayoutPanel1.Controls.Add(this.panel2);
            this.flowLayoutPanel1.Controls.Add(this.panel3);
            this.flowLayoutPanel1.Controls.Add(this.panel4);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(21, 12);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1044, 687);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.lblPrecioJac1);
            this.panel1.Controls.Add(this.lblPrecioGeely);
            this.panel1.Controls.Add(this.lblPrecioZeekrX);
            this.panel1.Controls.Add(this.lblPrecioJac4);
            this.panel1.Controls.Add(this.btnJac1);
            this.panel1.Controls.Add(this.btnGeely);
            this.panel1.Controls.Add(this.lblJac1);
            this.panel1.Controls.Add(this.lblGeely);
            this.panel1.Controls.Add(this.btnZeerkX);
            this.panel1.Controls.Add(this.lblZeekrX);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.btnJac4);
            this.panel1.Controls.Add(this.lblJac4);
            this.panel1.Controls.Add(this.pbJac1);
            this.panel1.Controls.Add(this.pbZeekrX);
            this.panel1.Controls.Add(this.pbGeely);
            this.panel1.Controls.Add(this.pbJac4);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(996, 324);
            this.panel1.TabIndex = 0;
            // 
            // lblPrecioJac1
            // 
            this.lblPrecioJac1.AutoSize = true;
            this.lblPrecioJac1.Font = new System.Drawing.Font("Perpetua Titling MT", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioJac1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblPrecioJac1.Location = new System.Drawing.Point(763, 251);
            this.lblPrecioJac1.Name = "lblPrecioJac1";
            this.lblPrecioJac1.Size = new System.Drawing.Size(99, 18);
            this.lblPrecioJac1.TabIndex = 34;
            this.lblPrecioJac1.Text = "₡12,320,000";
            // 
            // lblPrecioGeely
            // 
            this.lblPrecioGeely.AutoSize = true;
            this.lblPrecioGeely.Font = new System.Drawing.Font("Perpetua Titling MT", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioGeely.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblPrecioGeely.Location = new System.Drawing.Point(532, 251);
            this.lblPrecioGeely.Name = "lblPrecioGeely";
            this.lblPrecioGeely.Size = new System.Drawing.Size(101, 18);
            this.lblPrecioGeely.TabIndex = 33;
            this.lblPrecioGeely.Text = "₡16,240,000";
            // 
            // lblPrecioZeekrX
            // 
            this.lblPrecioZeekrX.AutoSize = true;
            this.lblPrecioZeekrX.Font = new System.Drawing.Font("Perpetua Titling MT", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioZeekrX.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblPrecioZeekrX.Location = new System.Drawing.Point(318, 251);
            this.lblPrecioZeekrX.Name = "lblPrecioZeekrX";
            this.lblPrecioZeekrX.Size = new System.Drawing.Size(101, 18);
            this.lblPrecioZeekrX.TabIndex = 32;
            this.lblPrecioZeekrX.Text = "₡22,984,950";
            // 
            // lblPrecioJac4
            // 
            this.lblPrecioJac4.AutoSize = true;
            this.lblPrecioJac4.Font = new System.Drawing.Font("Perpetua Titling MT", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioJac4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblPrecioJac4.Location = new System.Drawing.Point(107, 251);
            this.lblPrecioJac4.Name = "lblPrecioJac4";
            this.lblPrecioJac4.Size = new System.Drawing.Size(109, 18);
            this.lblPrecioJac4.TabIndex = 31;
            this.lblPrecioJac4.Text = "  ₡14,392,000";
            // 
            // btnJac1
            // 
            this.btnJac1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnJac1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJac1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJac1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnJac1.Location = new System.Drawing.Point(747, 281);
            this.btnJac1.Name = "btnJac1";
            this.btnJac1.Size = new System.Drawing.Size(145, 36);
            this.btnJac1.TabIndex = 30;
            this.btnJac1.Text = "Ver mas detalles";
            this.btnJac1.UseVisualStyleBackColor = false;
            this.btnJac1.Click += new System.EventHandler(this.btnJac1_Click);
            // 
            // btnGeely
            // 
            this.btnGeely.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnGeely.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGeely.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeely.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnGeely.Location = new System.Drawing.Point(512, 281);
            this.btnGeely.Name = "btnGeely";
            this.btnGeely.Size = new System.Drawing.Size(145, 36);
            this.btnGeely.TabIndex = 29;
            this.btnGeely.Text = "Ver mas detalles";
            this.btnGeely.UseVisualStyleBackColor = false;
            this.btnGeely.Click += new System.EventHandler(this.btnGeely_Click);
            // 
            // lblJac1
            // 
            this.lblJac1.AutoSize = true;
            this.lblJac1.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJac1.Location = new System.Drawing.Point(762, 229);
            this.lblJac1.Name = "lblJac1";
            this.lblJac1.Size = new System.Drawing.Size(92, 21);
            this.lblJac1.TabIndex = 28;
            this.lblJac1.Text = " JAC e-JS1";
            // 
            // lblGeely
            // 
            this.lblGeely.AutoSize = true;
            this.lblGeely.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGeely.Location = new System.Drawing.Point(499, 229);
            this.lblGeely.Name = "lblGeely";
            this.lblGeely.Size = new System.Drawing.Size(169, 21);
            this.lblGeely.TabIndex = 27;
            this.lblGeely.Text = "Geely Coolray ";
            // 
            // btnZeerkX
            // 
            this.btnZeerkX.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnZeerkX.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnZeerkX.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnZeerkX.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnZeerkX.Location = new System.Drawing.Point(286, 281);
            this.btnZeerkX.Name = "btnZeerkX";
            this.btnZeerkX.Size = new System.Drawing.Size(145, 36);
            this.btnZeerkX.TabIndex = 26;
            this.btnZeerkX.Text = "Ver mas detalles";
            this.btnZeerkX.UseVisualStyleBackColor = false;
            this.btnZeerkX.Click += new System.EventHandler(this.btnZeerkX_Click);
            // 
            // lblZeekrX
            // 
            this.lblZeekrX.AutoSize = true;
            this.lblZeekrX.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblZeekrX.Location = new System.Drawing.Point(323, 229);
            this.lblZeekrX.Name = "lblZeekrX";
            this.lblZeekrX.Size = new System.Drawing.Size(96, 21);
            this.lblZeekrX.TabIndex = 25;
            this.lblZeekrX.Text = "Zeekr X ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Perpetua Titling MT", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Maroon;
            this.label2.Location = new System.Drawing.Point(23, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 22);
            this.label2.TabIndex = 24;
            this.label2.Text = "ELECTRICOS";
            // 
            // btnJac4
            // 
            this.btnJac4.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnJac4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJac4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJac4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnJac4.Location = new System.Drawing.Point(82, 281);
            this.btnJac4.Name = "btnJac4";
            this.btnJac4.Size = new System.Drawing.Size(145, 36);
            this.btnJac4.TabIndex = 23;
            this.btnJac4.Text = "Ver mas detalles";
            this.btnJac4.UseVisualStyleBackColor = false;
            this.btnJac4.Click += new System.EventHandler(this.btnJac4_Click);
            // 
            // lblJac4
            // 
            this.lblJac4.AutoSize = true;
            this.lblJac4.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJac4.Location = new System.Drawing.Point(106, 229);
            this.lblJac4.Name = "lblJac4";
            this.lblJac4.Size = new System.Drawing.Size(97, 21);
            this.lblJac4.TabIndex = 22;
            this.lblJac4.Text = " JAC e-JS4";
            // 
            // pbJac1
            // 
            this.pbJac1.Image = ((System.Drawing.Image)(resources.GetObject("pbJac1.Image")));
            this.pbJac1.Location = new System.Drawing.Point(711, 41);
            this.pbJac1.Name = "pbJac1";
            this.pbJac1.Size = new System.Drawing.Size(193, 185);
            this.pbJac1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbJac1.TabIndex = 8;
            this.pbJac1.TabStop = false;
            // 
            // pbZeekrX
            // 
            this.pbZeekrX.Image = ((System.Drawing.Image)(resources.GetObject("pbZeekrX.Image")));
            this.pbZeekrX.Location = new System.Drawing.Point(278, 41);
            this.pbZeekrX.Name = "pbZeekrX";
            this.pbZeekrX.Size = new System.Drawing.Size(193, 185);
            this.pbZeekrX.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbZeekrX.TabIndex = 7;
            this.pbZeekrX.TabStop = false;
            // 
            // pbGeely
            // 
            this.pbGeely.Image = ((System.Drawing.Image)(resources.GetObject("pbGeely.Image")));
            this.pbGeely.Location = new System.Drawing.Point(483, 41);
            this.pbGeely.Name = "pbGeely";
            this.pbGeely.Size = new System.Drawing.Size(193, 185);
            this.pbGeely.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbGeely.TabIndex = 6;
            this.pbGeely.TabStop = false;
            // 
            // pbJac4
            // 
            this.pbJac4.Image = ((System.Drawing.Image)(resources.GetObject("pbJac4.Image")));
            this.pbJac4.Location = new System.Drawing.Point(68, 41);
            this.pbJac4.Name = "pbJac4";
            this.pbJac4.Size = new System.Drawing.Size(193, 185);
            this.pbJac4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbJac4.TabIndex = 5;
            this.pbJac4.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.Controls.Add(this.lblPrecioHilux);
            this.panel2.Controls.Add(this.lblPrecioNissan);
            this.panel2.Controls.Add(this.lblChevrolet);
            this.panel2.Controls.Add(this.lblPrecioJacT8);
            this.panel2.Controls.Add(this.lblHilux);
            this.panel2.Controls.Add(this.lblNissan);
            this.panel2.Controls.Add(this.lblPrecioChevrolet);
            this.panel2.Controls.Add(this.btnHilux);
            this.panel2.Controls.Add(this.btnNissan);
            this.panel2.Controls.Add(this.btnChevrolet);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.btnJacT8);
            this.panel2.Controls.Add(this.lblJact8);
            this.panel2.Controls.Add(this.pictureBox8);
            this.panel2.Controls.Add(this.pbChevrolet);
            this.panel2.Controls.Add(this.pb);
            this.panel2.Controls.Add(this.pbJacT8);
            this.panel2.Location = new System.Drawing.Point(3, 333);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(996, 345);
            this.panel2.TabIndex = 1;
            // 
            // lblPrecioHilux
            // 
            this.lblPrecioHilux.AutoSize = true;
            this.lblPrecioHilux.Font = new System.Drawing.Font("Perpetua Titling MT", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioHilux.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblPrecioHilux.Location = new System.Drawing.Point(761, 261);
            this.lblPrecioHilux.Name = "lblPrecioHilux";
            this.lblPrecioHilux.Size = new System.Drawing.Size(101, 18);
            this.lblPrecioHilux.TabIndex = 55;
            this.lblPrecioHilux.Text = "₡15,000,000";
            // 
            // lblPrecioNissan
            // 
            this.lblPrecioNissan.AutoSize = true;
            this.lblPrecioNissan.Font = new System.Drawing.Font("Perpetua Titling MT", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioNissan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblPrecioNissan.Location = new System.Drawing.Point(557, 261);
            this.lblPrecioNissan.Name = "lblPrecioNissan";
            this.lblPrecioNissan.Size = new System.Drawing.Size(100, 18);
            this.lblPrecioNissan.TabIndex = 54;
            this.lblPrecioNissan.Text = "₡21,280,000";
            // 
            // lblChevrolet
            // 
            this.lblChevrolet.AutoSize = true;
            this.lblChevrolet.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChevrolet.Location = new System.Drawing.Point(323, 240);
            this.lblChevrolet.Name = "lblChevrolet";
            this.lblChevrolet.Size = new System.Drawing.Size(119, 21);
            this.lblChevrolet.TabIndex = 53;
            this.lblChevrolet.Text = "Chevrolet";
            // 
            // lblPrecioJacT8
            // 
            this.lblPrecioJacT8.AutoSize = true;
            this.lblPrecioJacT8.Font = new System.Drawing.Font("Perpetua Titling MT", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioJacT8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblPrecioJacT8.Location = new System.Drawing.Point(107, 261);
            this.lblPrecioJacT8.Name = "lblPrecioJacT8";
            this.lblPrecioJacT8.Size = new System.Drawing.Size(105, 18);
            this.lblPrecioJacT8.TabIndex = 52;
            this.lblPrecioJacT8.Text = "₡19,600,000.";
            // 
            // lblHilux
            // 
            this.lblHilux.AutoSize = true;
            this.lblHilux.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHilux.Location = new System.Drawing.Point(718, 240);
            this.lblHilux.Name = "lblHilux";
            this.lblHilux.Size = new System.Drawing.Size(186, 21);
            this.lblHilux.TabIndex = 51;
            this.lblHilux.Text = "Toyota Hilux \'94";
            // 
            // lblNissan
            // 
            this.lblNissan.AutoSize = true;
            this.lblNissan.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNissan.Location = new System.Drawing.Point(508, 240);
            this.lblNissan.Name = "lblNissan";
            this.lblNissan.Size = new System.Drawing.Size(182, 21);
            this.lblNissan.TabIndex = 50;
            this.lblNissan.Text = " Nissan Frontier";
            // 
            // lblPrecioChevrolet
            // 
            this.lblPrecioChevrolet.AutoSize = true;
            this.lblPrecioChevrolet.Font = new System.Drawing.Font("Perpetua Titling MT", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioChevrolet.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblPrecioChevrolet.Location = new System.Drawing.Point(332, 261);
            this.lblPrecioChevrolet.Name = "lblPrecioChevrolet";
            this.lblPrecioChevrolet.Size = new System.Drawing.Size(99, 18);
            this.lblPrecioChevrolet.TabIndex = 49;
            this.lblPrecioChevrolet.Text = "₡19,768,000";
            // 
            // btnHilux
            // 
            this.btnHilux.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnHilux.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHilux.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHilux.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnHilux.Location = new System.Drawing.Point(747, 296);
            this.btnHilux.Name = "btnHilux";
            this.btnHilux.Size = new System.Drawing.Size(145, 36);
            this.btnHilux.TabIndex = 32;
            this.btnHilux.Text = "Ver mas detalles";
            this.btnHilux.UseVisualStyleBackColor = false;
            this.btnHilux.Click += new System.EventHandler(this.btnHilux_Click);
            // 
            // btnNissan
            // 
            this.btnNissan.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnNissan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNissan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNissan.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnNissan.Location = new System.Drawing.Point(523, 296);
            this.btnNissan.Name = "btnNissan";
            this.btnNissan.Size = new System.Drawing.Size(145, 36);
            this.btnNissan.TabIndex = 31;
            this.btnNissan.Text = "Ver mas detalles";
            this.btnNissan.UseVisualStyleBackColor = false;
            this.btnNissan.Click += new System.EventHandler(this.btnNissan_Click);
            // 
            // btnChevrolet
            // 
            this.btnChevrolet.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnChevrolet.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChevrolet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChevrolet.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnChevrolet.Location = new System.Drawing.Point(314, 296);
            this.btnChevrolet.Name = "btnChevrolet";
            this.btnChevrolet.Size = new System.Drawing.Size(145, 36);
            this.btnChevrolet.TabIndex = 30;
            this.btnChevrolet.Text = "Ver mas detalles";
            this.btnChevrolet.UseVisualStyleBackColor = false;
            this.btnChevrolet.Click += new System.EventHandler(this.btnChevrolet_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Perpetua Titling MT", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(29, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 22);
            this.label1.TabIndex = 28;
            this.label1.Text = "Pick Up";
            // 
            // btnJacT8
            // 
            this.btnJacT8.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnJacT8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJacT8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJacT8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnJacT8.Location = new System.Drawing.Point(94, 296);
            this.btnJacT8.Name = "btnJacT8";
            this.btnJacT8.Size = new System.Drawing.Size(145, 36);
            this.btnJacT8.TabIndex = 27;
            this.btnJacT8.Text = "Ver mas detalles";
            this.btnJacT8.UseVisualStyleBackColor = false;
            this.btnJacT8.Click += new System.EventHandler(this.btnJacT8_Click);
            // 
            // lblJact8
            // 
            this.lblJact8.AutoSize = true;
            this.lblJact8.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJact8.Location = new System.Drawing.Point(102, 240);
            this.lblJact8.Name = "lblJact8";
            this.lblJact8.Size = new System.Drawing.Size(114, 21);
            this.lblJact8.TabIndex = 26;
            this.lblJact8.Text = "JAC T8 Pro";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(711, 52);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(193, 183);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 10;
            this.pictureBox8.TabStop = false;
            // 
            // pbChevrolet
            // 
            this.pbChevrolet.Image = ((System.Drawing.Image)(resources.GetObject("pbChevrolet.Image")));
            this.pbChevrolet.Location = new System.Drawing.Point(286, 52);
            this.pbChevrolet.Name = "pbChevrolet";
            this.pbChevrolet.Size = new System.Drawing.Size(193, 185);
            this.pbChevrolet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbChevrolet.TabIndex = 9;
            this.pbChevrolet.TabStop = false;
            // 
            // pb
            // 
            this.pb.Image = ((System.Drawing.Image)(resources.GetObject("pb.Image")));
            this.pb.Location = new System.Drawing.Point(501, 52);
            this.pb.Name = "pb";
            this.pb.Size = new System.Drawing.Size(193, 185);
            this.pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb.TabIndex = 8;
            this.pb.TabStop = false;
            // 
            // pbJacT8
            // 
            this.pbJacT8.Image = ((System.Drawing.Image)(resources.GetObject("pbJacT8.Image")));
            this.pbJacT8.Location = new System.Drawing.Point(72, 52);
            this.pbJacT8.Name = "pbJacT8";
            this.pbJacT8.Size = new System.Drawing.Size(193, 185);
            this.pbJacT8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbJacT8.TabIndex = 7;
            this.pbJacT8.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.Controls.Add(this.lblPrecioAccent);
            this.panel3.Controls.Add(this.lblPrecioSuzuki);
            this.panel3.Controls.Add(this.lblPrecioYaris);
            this.panel3.Controls.Add(this.lblAudi);
            this.panel3.Controls.Add(this.lblAccent);
            this.panel3.Controls.Add(this.lblSuzuki);
            this.panel3.Controls.Add(this.btnAccent);
            this.panel3.Controls.Add(this.btnSuzuki);
            this.panel3.Controls.Add(this.pbSuzuki);
            this.panel3.Controls.Add(this.btnYaris);
            this.panel3.Controls.Add(this.lblYaris);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.pbAccent);
            this.panel3.Controls.Add(this.btnAudi);
            this.panel3.Controls.Add(this.lblAudio);
            this.panel3.Controls.Add(this.pbYaris);
            this.panel3.Controls.Add(this.pbAudi);
            this.panel3.Location = new System.Drawing.Point(3, 684);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(996, 335);
            this.panel3.TabIndex = 2;
            // 
            // lblPrecioAccent
            // 
            this.lblPrecioAccent.AutoSize = true;
            this.lblPrecioAccent.Font = new System.Drawing.Font("Perpetua Titling MT", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioAccent.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblPrecioAccent.Location = new System.Drawing.Point(763, 251);
            this.lblPrecioAccent.Name = "lblPrecioAccent";
            this.lblPrecioAccent.Size = new System.Drawing.Size(104, 18);
            this.lblPrecioAccent.TabIndex = 60;
            this.lblPrecioAccent.Text = "₡12,880,000.";
            // 
            // lblPrecioSuzuki
            // 
            this.lblPrecioSuzuki.AutoSize = true;
            this.lblPrecioSuzuki.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioSuzuki.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblPrecioSuzuki.Location = new System.Drawing.Point(531, 249);
            this.lblPrecioSuzuki.Name = "lblPrecioSuzuki";
            this.lblPrecioSuzuki.Size = new System.Drawing.Size(120, 21);
            this.lblPrecioSuzuki.TabIndex = 59;
            this.lblPrecioSuzuki.Text = "₡13,440,000.";
            // 
            // lblPrecioYaris
            // 
            this.lblPrecioYaris.AutoSize = true;
            this.lblPrecioYaris.Font = new System.Drawing.Font("Perpetua Titling MT", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioYaris.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblPrecioYaris.Location = new System.Drawing.Point(343, 249);
            this.lblPrecioYaris.Name = "lblPrecioYaris";
            this.lblPrecioYaris.Size = new System.Drawing.Size(99, 18);
            this.lblPrecioYaris.TabIndex = 58;
            this.lblPrecioYaris.Text = "₡13,720,000";
            // 
            // lblAudi
            // 
            this.lblAudi.AutoSize = true;
            this.lblAudi.Font = new System.Drawing.Font("Perpetua Titling MT", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAudi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblAudi.Location = new System.Drawing.Point(121, 249);
            this.lblAudi.Name = "lblAudi";
            this.lblAudi.Size = new System.Drawing.Size(106, 18);
            this.lblAudi.TabIndex = 57;
            this.lblAudi.Text = "₡20,048,000";
            // 
            // lblAccent
            // 
            this.lblAccent.AutoSize = true;
            this.lblAccent.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccent.Location = new System.Drawing.Point(718, 228);
            this.lblAccent.Name = "lblAccent";
            this.lblAccent.Size = new System.Drawing.Size(188, 21);
            this.lblAccent.TabIndex = 56;
            this.lblAccent.Text = " Hyundai Accent";
            // 
            // lblSuzuki
            // 
            this.lblSuzuki.AutoSize = true;
            this.lblSuzuki.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSuzuki.Location = new System.Drawing.Point(551, 228);
            this.lblSuzuki.Name = "lblSuzuki";
            this.lblSuzuki.Size = new System.Drawing.Size(82, 21);
            this.lblSuzuki.TabIndex = 55;
            this.lblSuzuki.Text = "Suzuki";
            // 
            // btnAccent
            // 
            this.btnAccent.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAccent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAccent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccent.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnAccent.Location = new System.Drawing.Point(747, 281);
            this.btnAccent.Name = "btnAccent";
            this.btnAccent.Size = new System.Drawing.Size(145, 36);
            this.btnAccent.TabIndex = 54;
            this.btnAccent.Text = "Ver mas detalles";
            this.btnAccent.UseVisualStyleBackColor = false;
            this.btnAccent.Click += new System.EventHandler(this.btnAccent_Click);
            // 
            // btnSuzuki
            // 
            this.btnSuzuki.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnSuzuki.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSuzuki.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuzuki.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnSuzuki.Location = new System.Drawing.Point(523, 281);
            this.btnSuzuki.Name = "btnSuzuki";
            this.btnSuzuki.Size = new System.Drawing.Size(145, 36);
            this.btnSuzuki.TabIndex = 53;
            this.btnSuzuki.Text = "Ver mas detalles";
            this.btnSuzuki.UseVisualStyleBackColor = false;
            this.btnSuzuki.Click += new System.EventHandler(this.btnSuzuki_Click);
            // 
            // pbSuzuki
            // 
            this.pbSuzuki.Image = ((System.Drawing.Image)(resources.GetObject("pbSuzuki.Image")));
            this.pbSuzuki.Location = new System.Drawing.Point(490, 42);
            this.pbSuzuki.Name = "pbSuzuki";
            this.pbSuzuki.Size = new System.Drawing.Size(200, 183);
            this.pbSuzuki.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSuzuki.TabIndex = 52;
            this.pbSuzuki.TabStop = false;
            // 
            // btnYaris
            // 
            this.btnYaris.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnYaris.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnYaris.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnYaris.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnYaris.Location = new System.Drawing.Point(321, 281);
            this.btnYaris.Name = "btnYaris";
            this.btnYaris.Size = new System.Drawing.Size(145, 36);
            this.btnYaris.TabIndex = 51;
            this.btnYaris.Text = "Ver mas detalles";
            this.btnYaris.UseVisualStyleBackColor = false;
            this.btnYaris.Click += new System.EventHandler(this.btnYaris_Click);
            // 
            // lblYaris
            // 
            this.lblYaris.AutoSize = true;
            this.lblYaris.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYaris.Location = new System.Drawing.Point(309, 228);
            this.lblYaris.Name = "lblYaris";
            this.lblYaris.Size = new System.Drawing.Size(150, 21);
            this.lblYaris.TabIndex = 50;
            this.lblYaris.Text = "Toyota Yaris";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Perpetua Titling MT", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Maroon;
            this.label12.Location = new System.Drawing.Point(29, 7);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(149, 22);
            this.label12.TabIndex = 49;
            this.label12.Text = "Automoviles";
            // 
            // pbAccent
            // 
            this.pbAccent.Image = ((System.Drawing.Image)(resources.GetObject("pbAccent.Image")));
            this.pbAccent.Location = new System.Drawing.Point(711, 42);
            this.pbAccent.Name = "pbAccent";
            this.pbAccent.Size = new System.Drawing.Size(193, 183);
            this.pbAccent.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbAccent.TabIndex = 18;
            this.pbAccent.TabStop = false;
            // 
            // btnAudi
            // 
            this.btnAudi.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAudi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAudi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAudi.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnAudi.Location = new System.Drawing.Point(106, 281);
            this.btnAudi.Name = "btnAudi";
            this.btnAudi.Size = new System.Drawing.Size(145, 36);
            this.btnAudi.TabIndex = 48;
            this.btnAudi.Text = "Ver mas detalles";
            this.btnAudi.UseVisualStyleBackColor = false;
            this.btnAudi.Click += new System.EventHandler(this.btnAudi_Click);
            // 
            // lblAudio
            // 
            this.lblAudio.AutoSize = true;
            this.lblAudio.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAudio.Location = new System.Drawing.Point(130, 228);
            this.lblAudio.Name = "lblAudio";
            this.lblAudio.Size = new System.Drawing.Size(86, 21);
            this.lblAudio.TabIndex = 47;
            this.lblAudio.Text = "Audi A3";
            // 
            // pbYaris
            // 
            this.pbYaris.Image = ((System.Drawing.Image)(resources.GetObject("pbYaris.Image")));
            this.pbYaris.Location = new System.Drawing.Point(293, 42);
            this.pbYaris.Name = "pbYaris";
            this.pbYaris.Size = new System.Drawing.Size(186, 183);
            this.pbYaris.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbYaris.TabIndex = 15;
            this.pbYaris.TabStop = false;
            // 
            // pbAudi
            // 
            this.pbAudi.Image = ((System.Drawing.Image)(resources.GetObject("pbAudi.Image")));
            this.pbAudi.Location = new System.Drawing.Point(80, 42);
            this.pbAudi.Name = "pbAudi";
            this.pbAudi.Size = new System.Drawing.Size(185, 183);
            this.pbAudi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbAudi.TabIndex = 14;
            this.pbAudi.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnSalir);
            this.panel4.Location = new System.Drawing.Point(3, 1025);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(996, 104);
            this.panel4.TabIndex = 3;
            // 
            // btnSalir
            // 
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.Location = new System.Drawing.Point(437, 32);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(125, 57);
            this.btnSalir.TabIndex = 66;
            this.btnSalir.Text = "&Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // frmCatalogoVehiculos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 737);
            this.ControlBox = false;
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "frmCatalogoVehiculos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Catalogo Vehiculos";
            this.Load += new System.EventHandler(this.frmCatalogoVehiculos_Load);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbJac1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbZeekrX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGeely)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbJac4)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbChevrolet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbJacT8)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSuzuki)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAccent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbYaris)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAudi)).EndInit();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pbJac1;
        private System.Windows.Forms.PictureBox pbZeekrX;
        private System.Windows.Forms.PictureBox pbGeely;
        private System.Windows.Forms.PictureBox pbJac4;
        private System.Windows.Forms.Button btnJac4;
        private System.Windows.Forms.Label lblJac4;
        private System.Windows.Forms.PictureBox pbChevrolet;
        private System.Windows.Forms.PictureBox pb;
        private System.Windows.Forms.PictureBox pbJacT8;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Button btnJacT8;
        private System.Windows.Forms.Label lblJact8;
        private System.Windows.Forms.PictureBox pbYaris;
        private System.Windows.Forms.PictureBox pbAudi;
        private System.Windows.Forms.Button btnAudi;
        private System.Windows.Forms.Label lblAudio;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbAccent;
        private System.Windows.Forms.Button btnZeerkX;
        private System.Windows.Forms.Label lblZeekrX;
        private System.Windows.Forms.Label lblGeely;
        private System.Windows.Forms.Label lblJac1;
        private System.Windows.Forms.Button btnJac1;
        private System.Windows.Forms.Button btnGeely;
        private System.Windows.Forms.Button btnHilux;
        private System.Windows.Forms.Button btnNissan;
        private System.Windows.Forms.Button btnChevrolet;
        private System.Windows.Forms.Label lblPrecioChevrolet;
        private System.Windows.Forms.Label lblNissan;
        private System.Windows.Forms.Label lblHilux;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblYaris;
        private System.Windows.Forms.Button btnYaris;
        private System.Windows.Forms.Button btnAccent;
        private System.Windows.Forms.Button btnSuzuki;
        private System.Windows.Forms.PictureBox pbSuzuki;
        private System.Windows.Forms.Label lblSuzuki;
        private System.Windows.Forms.Label lblAccent;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Label lblPrecioJac4;
        private System.Windows.Forms.Label lblPrecioZeekrX;
        private System.Windows.Forms.Label lblPrecioGeely;
        private System.Windows.Forms.Label lblPrecioJac1;
        private System.Windows.Forms.Label lblPrecioJacT8;
        private System.Windows.Forms.Label lblChevrolet;
        private System.Windows.Forms.Label lblPrecioNissan;
        private System.Windows.Forms.Label lblPrecioHilux;
        private System.Windows.Forms.Label lblAudi;
        private System.Windows.Forms.Label lblPrecioYaris;
        private System.Windows.Forms.Label lblPrecioSuzuki;
        private System.Windows.Forms.Label lblPrecioAccent;
    }
}