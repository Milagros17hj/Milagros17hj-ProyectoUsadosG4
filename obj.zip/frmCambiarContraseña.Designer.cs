﻿namespace ProyectoUsadosGrupo4
{
    partial class frmCambiarContraseña
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbUsuario = new System.Windows.Forms.GroupBox();
            this.txtConfirmar = new System.Windows.Forms.TextBox();
            this.lblConfirmContraseña = new System.Windows.Forms.Label();
            this.lblContraseñaNueva = new System.Windows.Forms.Label();
            this.txtContraseñaNueva = new System.Windows.Forms.TextBox();
            this.lblContraseñaAct = new System.Windows.Forms.Label();
            this.txtContraseñaAct = new System.Windows.Forms.TextBox();
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.lblUsuario = new System.Windows.Forms.Label();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnCambiar = new System.Windows.Forms.Button();
            this.grbUsuario.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbUsuario
            // 
            this.grbUsuario.Controls.Add(this.txtConfirmar);
            this.grbUsuario.Controls.Add(this.lblConfirmContraseña);
            this.grbUsuario.Controls.Add(this.lblContraseñaNueva);
            this.grbUsuario.Controls.Add(this.txtContraseñaNueva);
            this.grbUsuario.Controls.Add(this.lblContraseñaAct);
            this.grbUsuario.Controls.Add(this.txtContraseñaAct);
            this.grbUsuario.Controls.Add(this.txtUsuario);
            this.grbUsuario.Controls.Add(this.lblUsuario);
            this.grbUsuario.Location = new System.Drawing.Point(31, 26);
            this.grbUsuario.Name = "grbUsuario";
            this.grbUsuario.Size = new System.Drawing.Size(425, 325);
            this.grbUsuario.TabIndex = 0;
            this.grbUsuario.TabStop = false;
            this.grbUsuario.Text = "Usuario";
            // 
            // txtConfirmar
            // 
            this.txtConfirmar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConfirmar.Location = new System.Drawing.Point(226, 243);
            this.txtConfirmar.Name = "txtConfirmar";
            this.txtConfirmar.Size = new System.Drawing.Size(164, 27);
            this.txtConfirmar.TabIndex = 54;
            this.txtConfirmar.UseSystemPasswordChar = true;
            // 
            // lblConfirmContraseña
            // 
            this.lblConfirmContraseña.AutoSize = true;
            this.lblConfirmContraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfirmContraseña.Location = new System.Drawing.Point(29, 246);
            this.lblConfirmContraseña.Name = "lblConfirmContraseña";
            this.lblConfirmContraseña.Size = new System.Drawing.Size(179, 20);
            this.lblConfirmContraseña.TabIndex = 53;
            this.lblConfirmContraseña.Text = "Confirmar Contraseña:";
            // 
            // lblContraseñaNueva
            // 
            this.lblContraseñaNueva.AutoSize = true;
            this.lblContraseñaNueva.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContraseñaNueva.Location = new System.Drawing.Point(29, 197);
            this.lblContraseñaNueva.Name = "lblContraseñaNueva";
            this.lblContraseñaNueva.Size = new System.Drawing.Size(152, 20);
            this.lblContraseñaNueva.TabIndex = 52;
            this.lblContraseñaNueva.Text = "Contraseña Nueva:";
            // 
            // txtContraseñaNueva
            // 
            this.txtContraseñaNueva.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContraseñaNueva.Location = new System.Drawing.Point(226, 181);
            this.txtContraseñaNueva.Name = "txtContraseñaNueva";
            this.txtContraseñaNueva.Size = new System.Drawing.Size(164, 27);
            this.txtContraseñaNueva.TabIndex = 51;
            this.txtContraseñaNueva.UseSystemPasswordChar = true;
            // 
            // lblContraseñaAct
            // 
            this.lblContraseñaAct.AutoSize = true;
            this.lblContraseñaAct.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContraseñaAct.Location = new System.Drawing.Point(29, 109);
            this.lblContraseñaAct.Name = "lblContraseñaAct";
            this.lblContraseñaAct.Size = new System.Drawing.Size(152, 20);
            this.lblContraseñaAct.TabIndex = 50;
            this.lblContraseñaAct.Text = "Contraseña Actual:";
            // 
            // txtContraseñaAct
            // 
            this.txtContraseñaAct.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContraseñaAct.Location = new System.Drawing.Point(226, 106);
            this.txtContraseñaAct.Name = "txtContraseñaAct";
            this.txtContraseñaAct.Size = new System.Drawing.Size(164, 27);
            this.txtContraseñaAct.TabIndex = 0;
            this.txtContraseñaAct.UseSystemPasswordChar = true;
            // 
            // txtUsuario
            // 
            this.txtUsuario.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsuario.Location = new System.Drawing.Point(226, 55);
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.Size = new System.Drawing.Size(162, 27);
            this.txtUsuario.TabIndex = 47;
            // 
            // lblUsuario
            // 
            this.lblUsuario.AutoSize = true;
            this.lblUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsuario.Location = new System.Drawing.Point(29, 58);
            this.lblUsuario.Name = "lblUsuario";
            this.lblUsuario.Size = new System.Drawing.Size(72, 20);
            this.lblUsuario.TabIndex = 48;
            this.lblUsuario.Text = "Usuario:";
            // 
            // btnSalir
            // 
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.Location = new System.Drawing.Point(321, 379);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(125, 57);
            this.btnSalir.TabIndex = 71;
            this.btnSalir.Text = "&Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnCambiar
            // 
            this.btnCambiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCambiar.Location = new System.Drawing.Point(64, 379);
            this.btnCambiar.Name = "btnCambiar";
            this.btnCambiar.Size = new System.Drawing.Size(125, 57);
            this.btnCambiar.TabIndex = 72;
            this.btnCambiar.Text = "&Cambiar";
            this.btnCambiar.UseVisualStyleBackColor = true;
            this.btnCambiar.Click += new System.EventHandler(this.btnCambiar_Click);
            // 
            // frmCambiarContraseña
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(494, 470);
            this.ControlBox = false;
            this.Controls.Add(this.btnCambiar);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.grbUsuario);
            this.Name = "frmCambiarContraseña";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cambiar Contraseña";
            this.grbUsuario.ResumeLayout(false);
            this.grbUsuario.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbUsuario;
        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.Label lblUsuario;
        private System.Windows.Forms.Label lblContraseñaAct;
        private System.Windows.Forms.TextBox txtContraseñaAct;
        private System.Windows.Forms.Label lblContraseñaNueva;
        private System.Windows.Forms.TextBox txtContraseñaNueva;
        private System.Windows.Forms.TextBox txtConfirmar;
        private System.Windows.Forms.Label lblConfirmContraseña;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnCambiar;
    }
}